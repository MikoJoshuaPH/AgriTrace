-- AgriTrace database backup
-- Created: 2026-10-25T07:21:15+08:00

SET FOREIGN_KEY_CHECKS=0;

DROP TABLE IF EXISTS `audit_logs`;
CREATE TABLE "audit_logs" (
  "audit_id" int NOT NULL AUTO_INCREMENT,
  "user_id" int DEFAULT NULL,
  "action" varchar(150) NOT NULL,
  "entity_type" varchar(100) NOT NULL,
  "entity_id" int DEFAULT NULL,
  "details" text,
  "ip_address" varchar(45) DEFAULT NULL,
  "created_at" datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY ("audit_id"),
  KEY "fk_audit_user" ("user_id"),
  CONSTRAINT "fk_audit_user" FOREIGN KEY ("user_id") REFERENCES "users" ("id") ON DELETE SET NULL
);

INSERT INTO `audit_logs` (`audit_id`,`user_id`,`action`,`entity_type`,`entity_id`,`details`,`ip_address`,`created_at`) VALUES
(1,1,'CREATE_POST','Post',5,'cute ng birdy','127.0.0.1','2026-10-22 08:39:33'),
(2,1,'UPDATE_POST','Post',5,'cute ng birdy edited','127.0.0.1','2026-10-22 08:41:29'),
(3,1,'UPDATE_POST','Post',5,'cute ng birdy','127.0.0.1','2026-10-22 08:41:31'),
(4,1,'LOGIN','Auth',1,'Signed in without email code','127.0.0.1','2026-10-24 12:58:28'),
(5,1,'LOGIN','Auth',1,'Signed in without email code','127.0.0.1','2026-10-24 13:00:33'),
(6,1,'LOGIN','Auth',1,'Signed in without email code','127.0.0.1','2026-10-24 13:04:23'),
(7,1,'LOGIN','Auth',1,'Signed in without email code','127.0.0.1','2026-10-24 13:05:37'),
(8,1,'LOGIN','Auth',1,'Signed in without email code','127.0.0.1','2026-10-24 13:06:50'),
(9,1,'LOGIN','Auth',1,'Signed in without email code','127.0.0.1','2026-10-24 13:07:50'),
(10,1,'LOGIN_CODE_SENT','Auth',1,'Two-factor code emailed','127.0.0.1','2026-10-24 14:21:55'),
(11,1,'PLACE_ORDER','Order',1,'1 item(s)','127.0.0.1','2026-10-24 14:23:14'),
(12,1,'LOGIN_CODE_SENT','Auth',1,'Two-factor code emailed','127.0.0.1','2026-10-24 14:25:26'),
(13,1,'LOGIN','Auth',1,'Signed in with email code','127.0.0.1','2026-10-24 14:26:14'),
(14,1,'LOGIN_CODE_SENT','Auth',1,'Two-factor code emailed','127.0.0.1','2026-10-24 23:07:19'),
(15,1,'LOGIN','Auth',1,'Signed in with email code','127.0.0.1','2026-10-24 23:07:41'),
(16,1,'UPDATE_ACCOUNT','User',1,'profile_pic','127.0.0.1','2026-10-24 23:09:16'),
(17,1,'UPDATE_ACCOUNT','User',1,'location_label,latitude,longitude','127.0.0.1','2026-10-24 23:09:59');

DROP TABLE IF EXISTS `community_groups`;
CREATE TABLE "community_groups" (
  "group_id" int unsigned NOT NULL AUTO_INCREMENT,
  "name" varchar(150) NOT NULL,
  "category" varchar(50) NOT NULL,
  "created_at" datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY ("group_id"),
  UNIQUE KEY "name" ("name")
);

INSERT INTO `community_groups` (`group_id`,`name`,`category`,`created_at`) VALUES
(1,'Sustainable Farming PH','Community','2026-10-22 08:23:05'),
(2,'Organic Rice Growers','Crops','2026-10-22 08:23:05'),
(3,'Modern AgriTech Enthusiasts','AgriTech','2026-10-22 08:23:05'),
(4,'Backyard Gardening Tips','Community','2026-10-22 08:23:05'),
(5,'Livestock & Poultry PH','Livestock','2026-10-22 08:23:05'),
(6,'Urban Farming Community','Community','2026-10-22 08:23:06'),
(7,'Coconut Farmers Network','Crops','2026-10-22 08:23:06'),
(8,'Corn Producers Association','Crops','2026-10-22 08:23:06'),
(17,'Fresh Vegetables Traders','Crops','2026-10-24 14:11:26'),
(18,'Fruit Orchard Owners','Crops','2026-10-24 14:11:26'),
(19,'Agri-Business Startups','AgriTech','2026-10-24 14:11:27'),
(20,'Permaculture Philippines','Community','2026-10-24 14:11:27'),
(21,'Hydroponics & Aquaponics','AgriTech','2026-10-24 14:11:27'),
(22,'Farm Machinery Buy & Sell','AgriTech','2026-10-24 14:11:28'),
(23,'Weather & Crop Updates','Community','2026-10-24 14:11:28'),
(24,'AgriTourism PH','Community','2026-10-24 14:11:29'),
(25,'Young Farmers Club','Community','2026-10-24 14:11:29'),
(26,'Seed Savers Exchange','Crops','2026-10-24 14:11:29'),
(27,'Composting & Fertilizers','Crops','2026-10-24 14:11:30'),
(28,'Farm-to-Table Restaurants','Community','2026-10-24 14:11:31');

DROP TABLE IF EXISTS `community_posts`;
CREATE TABLE "community_posts" (
  "post_id" int unsigned NOT NULL AUTO_INCREMENT,
  "author_id" int unsigned NOT NULL,
  "content" text NOT NULL,
  "post_type" varchar(30) NOT NULL DEFAULT 'text',
  "listing_id" int unsigned DEFAULT NULL,
  "created_at" datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "media_url" varchar(255) DEFAULT NULL,
  "media_type" varchar(30) DEFAULT NULL,
  "status" varchar(20) NOT NULL DEFAULT 'approved',
  PRIMARY KEY ("post_id"),
  KEY "community_posts_author_idx" ("author_id"),
  KEY "community_posts_listing_idx" ("listing_id")
);

INSERT INTO `community_posts` (`post_id`,`author_id`,`content`,`post_type`,`listing_id`,`created_at`,`media_url`,`media_type`,`status`) VALUES
(1,5,'hi','text',NULL,'2026-10-20 17:33:43',NULL,NULL,'approved'),
(2,5,'Banana is now available on the AgriTrace Marketplace.','product',1,'2026-10-20 17:35:44',NULL,NULL,'approved'),
(3,5,'Test photo post','image',NULL,'2026-10-20 17:38:05','/uploads/community/c6e6d34eafda594fb96c40249db1d756.png','image','approved'),
(4,5,'media test','image',NULL,'2026-10-20 17:38:27','/uploads/community/test.png','image','approved'),
(5,1,'cute ng birdy','media',NULL,'2026-10-22 08:39:33','/uploads/community/97e3b353be14d49b2912ee64207df82b.jpg','image','approved');

DROP TABLE IF EXISTS `database_backups`;
CREATE TABLE "database_backups" (
  "backup_id" int NOT NULL AUTO_INCREMENT,
  "file_path" varchar(255) NOT NULL,
  "file_url" varchar(500) DEFAULT NULL,
  "size_bytes" bigint unsigned NOT NULL DEFAULT '0',
  "storage_driver" varchar(20) NOT NULL DEFAULT 'local',
  "status" enum('completed','failed') NOT NULL,
  "error_message" varchar(500) DEFAULT NULL,
  "created_by" int DEFAULT NULL,
  "created_at" datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY ("backup_id"),
  KEY "fk_backup_user" ("created_by"),
  CONSTRAINT "fk_backup_user" FOREIGN KEY ("created_by") REFERENCES "users" ("id") ON DELETE SET NULL
);


DROP TABLE IF EXISTS `farms`;
CREATE TABLE "farms" (
  "farm_id" int NOT NULL AUTO_INCREMENT,
  "farmer_id" int NOT NULL,
  "farm_name" varchar(150) NOT NULL,
  "farm_address" text,
  "province" varchar(100) DEFAULT NULL,
  "municipality" varchar(100) DEFAULT NULL,
  "barangay" varchar(100) DEFAULT NULL,
  "latitude" decimal(10,7) DEFAULT NULL,
  "longitude" decimal(10,7) DEFAULT NULL,
  "farm_size" decimal(10,2) DEFAULT NULL,
  "farm_size_unit" varchar(20) DEFAULT NULL,
  "created_at" datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY ("farm_id"),
  KEY "fk_farms_farmer" ("farmer_id"),
  CONSTRAINT "fk_farms_farmer" FOREIGN KEY ("farmer_id") REFERENCES "users" ("id")
);


DROP TABLE IF EXISTS `group_members`;
CREATE TABLE "group_members" (
  "group_id" int unsigned NOT NULL,
  "user_id" int NOT NULL,
  "joined_at" datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY ("group_id","user_id"),
  KEY "fk_gm_user" ("user_id"),
  CONSTRAINT "fk_gm_group" FOREIGN KEY ("group_id") REFERENCES "community_groups" ("group_id") ON DELETE CASCADE,
  CONSTRAINT "fk_gm_user" FOREIGN KEY ("user_id") REFERENCES "users" ("id") ON DELETE CASCADE
);


DROP TABLE IF EXISTS `harvest_records`;
CREATE TABLE "harvest_records" (
  "harvest_id" int NOT NULL AUTO_INCREMENT,
  "batch_id" int NOT NULL,
  "farmer_id" int NOT NULL,
  "harvest_date" date NOT NULL,
  "quantity_harvested" decimal(12,2) NOT NULL,
  "quality_grade" varchar(50) DEFAULT NULL,
  "notes" text,
  "created_at" datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY ("harvest_id"),
  KEY "fk_harvest_batch" ("batch_id"),
  KEY "fk_harvest_farmer" ("farmer_id"),
  CONSTRAINT "fk_harvest_batch" FOREIGN KEY ("batch_id") REFERENCES "product_batches" ("batch_id"),
  CONSTRAINT "fk_harvest_farmer" FOREIGN KEY ("farmer_id") REFERENCES "users" ("id")
);


DROP TABLE IF EXISTS `marketplace_listings`;
CREATE TABLE "marketplace_listings" (
  "listing_id" int unsigned NOT NULL AUTO_INCREMENT,
  "seller_id" int unsigned NOT NULL,
  "product_name" varchar(150) NOT NULL,
  "category" varchar(100) NOT NULL,
  "description" text,
  "price" decimal(12,2) NOT NULL,
  "stock" decimal(12,2) NOT NULL,
  "unit" varchar(30) NOT NULL,
  "location" varchar(255) DEFAULT NULL,
  "image_url" varchar(255) DEFAULT NULL,
  "is_available" tinyint(1) NOT NULL DEFAULT '1',
  "created_at" datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY ("listing_id"),
  KEY "marketplace_seller_idx" ("seller_id")
);

INSERT INTO `marketplace_listings` (`listing_id`,`seller_id`,`product_name`,`category`,`description`,`price`,`stock`,`unit`,`location`,`image_url`,`is_available`,`created_at`) VALUES
(1,5,'Banana','Fruits','CCC','190.00','9.00','piece','Ba','',1,'2026-10-20 17:35:41');

DROP TABLE IF EXISTS `markets`;
CREATE TABLE "markets" (
  "market_id" int NOT NULL AUTO_INCREMENT,
  "market_name" varchar(150) NOT NULL,
  "manager_id" int NOT NULL,
  "address" text,
  "province" varchar(100) DEFAULT NULL,
  "municipality" varchar(100) DEFAULT NULL,
  "contact_number" varchar(20) DEFAULT NULL,
  "latitude" decimal(10,7) DEFAULT NULL,
  "longitude" decimal(10,7) DEFAULT NULL,
  "created_at" datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY ("market_id"),
  KEY "fk_markets_manager" ("manager_id"),
  CONSTRAINT "fk_markets_manager" FOREIGN KEY ("manager_id") REFERENCES "users" ("id")
);


DROP TABLE IF EXISTS `messages`;
CREATE TABLE "messages" (
  "message_id" int unsigned NOT NULL AUTO_INCREMENT,
  "sender_id" int NOT NULL,
  "receiver_id" int NOT NULL,
  "body" text NOT NULL,
  "read_at" datetime DEFAULT NULL,
  "created_at" datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY ("message_id"),
  KEY "idx_msg_sender" ("sender_id"),
  KEY "idx_msg_receiver" ("receiver_id"),
  CONSTRAINT "fk_msg_receiver" FOREIGN KEY ("receiver_id") REFERENCES "users" ("id") ON DELETE CASCADE,
  CONSTRAINT "fk_msg_sender" FOREIGN KEY ("sender_id") REFERENCES "users" ("id") ON DELETE CASCADE
);


DROP TABLE IF EXISTS `migrations`;
CREATE TABLE "migrations" (
  "id" int NOT NULL AUTO_INCREMENT,
  "migration" int NOT NULL,
  "applied_at" datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY ("id")
);

INSERT INTO `migrations` (`id`,`migration`,`applied_at`) VALUES
(1,0,'2026-10-17 23:49:26'),
(2,1,'2026-10-17 23:49:26'),
(3,2,'2026-10-17 23:49:27'),
(4,3,'2026-10-20 17:30:43'),
(5,4,'2026-10-20 17:37:38'),
(6,5,'2026-10-24 14:11:31'),
(7,6,'2026-10-24 14:17:13');

DROP TABLE IF EXISTS `notifications`;
CREATE TABLE "notifications" (
  "notification_id" int NOT NULL AUTO_INCREMENT,
  "user_id" int NOT NULL,
  "title" varchar(150) NOT NULL,
  "message" text NOT NULL,
  "channel" enum('email','system') NOT NULL,
  "delivery_status" enum('pending','sent','failed','read') NOT NULL DEFAULT 'pending',
  "created_at" datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY ("notification_id"),
  KEY "fk_notif_user" ("user_id"),
  CONSTRAINT "fk_notif_user" FOREIGN KEY ("user_id") REFERENCES "users" ("id") ON DELETE CASCADE
);

INSERT INTO `notifications` (`notification_id`,`user_id`,`title`,`message`,`channel`,`delivery_status`,`created_at`) VALUES
(1,1,'Order #1 created','Complete the payment to confirm your order.','system','read','2026-10-24 14:23:13');

DROP TABLE IF EXISTS `order_items`;
CREATE TABLE "order_items" (
  "item_id" int unsigned NOT NULL AUTO_INCREMENT,
  "order_id" int unsigned NOT NULL,
  "listing_id" int unsigned DEFAULT NULL,
  "seller_id" int NOT NULL,
  "product_name" varchar(150) NOT NULL,
  "unit_price" decimal(12,2) NOT NULL,
  "quantity" decimal(12,2) NOT NULL,
  "unit" varchar(30) NOT NULL,
  PRIMARY KEY ("item_id"),
  KEY "fk_item_order" ("order_id"),
  KEY "fk_item_listing" ("listing_id"),
  KEY "fk_item_seller" ("seller_id"),
  CONSTRAINT "fk_item_listing" FOREIGN KEY ("listing_id") REFERENCES "marketplace_listings" ("listing_id") ON DELETE SET NULL,
  CONSTRAINT "fk_item_order" FOREIGN KEY ("order_id") REFERENCES "orders" ("order_id") ON DELETE CASCADE,
  CONSTRAINT "fk_item_seller" FOREIGN KEY ("seller_id") REFERENCES "users" ("id")
);

INSERT INTO `order_items` (`item_id`,`order_id`,`listing_id`,`seller_id`,`product_name`,`unit_price`,`quantity`,`unit`) VALUES
(1,1,1,5,'Banana','190.00','1.00','piece');

DROP TABLE IF EXISTS `orders`;
CREATE TABLE "orders" (
  "order_id" int unsigned NOT NULL AUTO_INCREMENT,
  "buyer_id" int NOT NULL,
  "total_amount" decimal(12,2) NOT NULL,
  "status" enum('pending','confirmed','completed','cancelled') NOT NULL DEFAULT 'pending',
  "created_at" datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "payment_status" varchar(20) NOT NULL DEFAULT 'unpaid',
  "xendit_invoice_id" varchar(100) DEFAULT NULL,
  "xendit_invoice_url" varchar(500) DEFAULT NULL,
  "payment_external_id" varchar(100) DEFAULT NULL,
  "paid_at" datetime DEFAULT NULL,
  PRIMARY KEY ("order_id"),
  KEY "fk_order_buyer" ("buyer_id"),
  CONSTRAINT "fk_order_buyer" FOREIGN KEY ("buyer_id") REFERENCES "users" ("id")
);

INSERT INTO `orders` (`order_id`,`buyer_id`,`total_amount`,`status`,`created_at`,`payment_status`,`xendit_invoice_id`,`xendit_invoice_url`,`payment_external_id`,`paid_at`) VALUES
(1,1,'190.00','pending','2026-10-24 14:23:09','unpaid','6adcbf50067792943255c00c','https://checkout-staging.xendit.co/web/6adcbf50067792943255c00c','AGT-ORDER-1-db1dcf',NULL);

DROP TABLE IF EXISTS `post_comments`;
CREATE TABLE "post_comments" (
  "comment_id" int unsigned NOT NULL AUTO_INCREMENT,
  "post_id" int unsigned NOT NULL,
  "author_id" int NOT NULL,
  "content" text NOT NULL,
  "created_at" datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY ("comment_id"),
  KEY "fk_comment_post" ("post_id"),
  KEY "fk_comment_author" ("author_id"),
  CONSTRAINT "fk_comment_author" FOREIGN KEY ("author_id") REFERENCES "users" ("id") ON DELETE CASCADE,
  CONSTRAINT "fk_comment_post" FOREIGN KEY ("post_id") REFERENCES "community_posts" ("post_id") ON DELETE CASCADE
);

INSERT INTO `post_comments` (`comment_id`,`post_id`,`author_id`,`content`,`created_at`) VALUES
(1,5,1,'hiii','2026-10-22 08:42:54');

DROP TABLE IF EXISTS `post_likes`;
CREATE TABLE "post_likes" (
  "id" int unsigned NOT NULL AUTO_INCREMENT,
  "post_id" int unsigned NOT NULL,
  "user_id" int NOT NULL,
  "created_at" datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY ("id"),
  UNIQUE KEY "uq_post_like" ("post_id","user_id"),
  KEY "fk_like_user" ("user_id"),
  CONSTRAINT "fk_like_post" FOREIGN KEY ("post_id") REFERENCES "community_posts" ("post_id") ON DELETE CASCADE,
  CONSTRAINT "fk_like_user" FOREIGN KEY ("user_id") REFERENCES "users" ("id") ON DELETE CASCADE
);

INSERT INTO `post_likes` (`id`,`post_id`,`user_id`,`created_at`) VALUES
(7,4,1,'2026-10-22 08:49:50'),
(8,5,1,'2026-10-22 08:50:00');

DROP TABLE IF EXISTS `product_batches`;
CREATE TABLE "product_batches" (
  "batch_id" int NOT NULL AUTO_INCREMENT,
  "batch_code" varchar(50) NOT NULL,
  "product_id" int NOT NULL,
  "farm_id" int NOT NULL,
  "quantity" decimal(12,2) NOT NULL,
  "unit" varchar(30) NOT NULL,
  "harvest_date" date DEFAULT NULL,
  "product_image" varchar(255) DEFAULT NULL,
  "current_status" enum('harvested','collected','in_transit','received','available_at_market','sold','rejected') NOT NULL DEFAULT 'harvested',
  "created_at" datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY ("batch_id"),
  UNIQUE KEY "batch_code" ("batch_code"),
  KEY "fk_batches_product" ("product_id"),
  KEY "fk_batches_farm" ("farm_id"),
  CONSTRAINT "fk_batches_farm" FOREIGN KEY ("farm_id") REFERENCES "farms" ("farm_id"),
  CONSTRAINT "fk_batches_product" FOREIGN KEY ("product_id") REFERENCES "products" ("product_id")
);


DROP TABLE IF EXISTS `products`;
CREATE TABLE "products" (
  "product_id" int NOT NULL AUTO_INCREMENT,
  "product_name" varchar(150) NOT NULL,
  "category" varchar(100) NOT NULL,
  "description" text,
  "unit_of_measure" varchar(30) NOT NULL,
  "created_at" datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY ("product_id")
);


DROP TABLE IF EXISTS `qr_codes`;
CREATE TABLE "qr_codes" (
  "qr_id" int NOT NULL AUTO_INCREMENT,
  "batch_id" int NOT NULL,
  "qr_token" varchar(255) NOT NULL,
  "qr_image_path" varchar(255) DEFAULT NULL,
  "is_active" tinyint(1) NOT NULL DEFAULT '1',
  "created_at" datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY ("qr_id"),
  UNIQUE KEY "batch_id" ("batch_id"),
  UNIQUE KEY "qr_token" ("qr_token"),
  CONSTRAINT "fk_qr_batch" FOREIGN KEY ("batch_id") REFERENCES "product_batches" ("batch_id")
);


DROP TABLE IF EXISTS `refresh_tokens`;
CREATE TABLE "refresh_tokens" (
  "id" int NOT NULL AUTO_INCREMENT,
  "user_id" int NOT NULL,
  "token" varchar(255) NOT NULL,
  "expires_at" datetime NOT NULL,
  "revoked_at" datetime DEFAULT NULL,
  "created_at" datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY ("id"),
  UNIQUE KEY "token" ("token"),
  KEY "fk_refresh_user" ("user_id"),
  CONSTRAINT "fk_refresh_user" FOREIGN KEY ("user_id") REFERENCES "users" ("id") ON DELETE CASCADE
);

INSERT INTO `refresh_tokens` (`id`,`user_id`,`token`,`expires_at`,`revoked_at`,`created_at`) VALUES
(1,3,'705398542b532d4a1dd8cd685e13acc5632e10193f3ba9a07726f26b7f8bc8bf','2026-10-25 08:58:22',NULL,'2026-10-18 00:58:22'),
(2,1,'52205b9de48f53463f7f9b84d4c87e7eda07e93f8747ed559d26ec86b7d40762','2026-10-27 11:06:22',NULL,'2026-10-20 03:06:21'),
(3,1,'6087d9d87abf881b3615f5335525147e43ea98b84de2259925db3bc97f67b8a0','2026-10-27 11:14:56',NULL,'2026-10-20 03:14:55'),
(4,1,'0595ec947fa6ae4381b3392b934636c56a4aedfed7b9867f6729b40da768fee4','2026-10-27 11:23:08',NULL,'2026-10-20 03:23:07'),
(5,1,'d91c05882d411605b60ff8adb66ccd46b2da6374267966dcffdd49fc744b7c21','2026-10-27 12:43:37',NULL,'2026-10-20 04:43:37'),
(6,1,'6db7b42a7a778f2598766a630869841a464575aac0b7939973f81d6d91b7884f','2026-10-27 12:45:29',NULL,'2026-10-20 04:45:28'),
(7,1,'f6b98177185c945774fe57c71e1c02a4fce7386c7e5f0238323da4c15ed6656c','2026-10-27 13:03:53',NULL,'2026-10-20 05:03:52'),
(8,1,'7d312f32d54a1b1b144ad2d50bbd649b33ed67e24bd8e63764d6fbc5ada1b392','2026-10-27 14:53:47',NULL,'2026-10-20 06:53:47'),
(9,1,'d38162c385d6ac7892bab056b6ce69c25b4a858fb110cfb03fa55988675bae80','2026-10-27 15:22:00',NULL,'2026-10-20 07:22:00'),
(10,1,'0a5bf15649cba4bdffb9a873c8e641586421ab3e9ec7cd0e2a2a11b072d96345','2026-10-27 22:49:33',NULL,'2026-10-20 14:49:32'),
(11,1,'c236f2a2bd96e8c5ce2742f56081430a7e051619d9bbf78cbcaf9c49b088cca2','2026-10-28 00:23:36',NULL,'2026-10-20 16:23:36'),
(12,1,'a8c603d1081f481a0ba46c5be35f92ae4cdf6742d96993fa66588d652a1e3633','2026-10-28 00:23:36',NULL,'2026-10-20 16:23:37'),
(13,1,'b555ec187149fc60332debe27f1188ee8be194cd15008a80c6ceed16ae5aad50','2026-10-28 00:25:25',NULL,'2026-10-20 16:25:25'),
(15,1,'95066602a43066c0a6c077d89fdc3b3e930da3171dc2bb143f5c554722c79d76','2026-10-28 00:45:22',NULL,'2026-10-20 16:45:22'),
(16,1,'ade19cc1105b906e12c6b94259b5acc056a5b04d30f535600d1869786f06170e','2026-10-28 00:50:51',NULL,'2026-10-20 16:50:51'),
(17,1,'e3c845cf12e6f1ccba41b681c187c35629ee6fa1312045576a215030ace2a3e2','2026-10-28 01:15:32',NULL,'2026-10-20 17:15:32'),
(18,1,'9fb1e326a6f3bc7aad5cc6e94d4904735b47d83c8165878719bea272899d2ef5','2026-10-28 01:17:47',NULL,'2026-10-20 17:17:46'),
(19,1,'08ab2e63f11d72d0618db92c7de3b2f54c9d8a4cc713428c93542d864d5ab3d3','2026-10-28 01:19:57',NULL,'2026-10-20 17:19:56'),
(21,5,'a7b0577872aa8ad3b10e8bf5548dc406699c264ea3aaae320ab3d6cc82d58d48','2026-10-28 01:26:50',NULL,'2026-10-20 17:26:49'),
(23,1,'0077a25ceb1effe855c6f92e948c827f37107f630909a6f039514ecbc84ef991','2026-10-28 08:09:55',NULL,'2026-10-21 00:09:55'),
(24,1,'2edf0d2a829d62d96d1ad173e58462d40e1f6630d5102c099c0736cb435adf74','2026-10-28 08:27:05',NULL,'2026-10-21 00:27:05'),
(27,1,'0222f1f8cf8bfdafc97e75f24195aa5198e56e49769bae7fe55ce5e472d2a27b','2026-10-29 16:15:10',NULL,'2026-10-22 08:15:10'),
(28,1,'453d8ef249f7e640d572e2265e32ef3dcb9c5e911051e80680b15c6f8c76aae3','2026-10-29 16:15:12',NULL,'2026-10-22 08:15:12'),
(30,1,'e12a9c2deb4564eb63e1a60605167c45d7c78d25fedb6a4bbe3e312528f7bc3c','2026-10-29 16:16:10',NULL,'2026-10-22 08:16:10'),
(31,1,'4e5173712661bc77d54d5fbf30a36db97cf7c783da3259f1b0e1aaad498d4b2c','2026-10-29 16:16:29',NULL,'2026-10-22 08:16:29'),
(32,1,'4759dcdb35dbe46e02dd0ceba8c81ddb689fd5f481d3b99827caf1b30c995fe7','2026-10-29 16:16:40',NULL,'2026-10-22 08:16:40'),
(33,1,'f24d6b6960cebd723af22afc52756b7eaae22f3a4e8ab49838006d3f22f3c3e5','2026-10-29 16:16:49',NULL,'2026-10-22 08:16:49'),
(34,1,'991680768fc152ab4ff4381d08837b802229e43091aa094494335c956eab0a56','2026-10-29 16:18:50',NULL,'2026-10-22 08:18:51'),
(35,1,'d7464043a6c84fb4dc6d0e1111ae33c09b26fd45a588510303928297afc2c9d9','2026-10-29 16:19:03',NULL,'2026-10-22 08:19:03'),
(36,1,'810f24ee2b2a757a94cb13bd54891a8abeec84116042fa8e087059c3e3e622a2','2026-10-29 16:19:10',NULL,'2026-10-22 08:19:10'),
(37,1,'16fc34138b028a079b339d1f5945ffbbad9ac2a1008c61bb8b59fa3ea4990bbb','2026-10-29 16:19:45',NULL,'2026-10-22 08:19:45'),
(38,1,'a95a4e21f677b56fc03d87e2539daf9255661c2888d803945f7fb038c4fdaf5b','2026-10-29 16:20:10',NULL,'2026-10-22 08:20:11'),
(39,1,'2cce826253159091904b5eca94f27c19686a470d1c1855407c936a2bdaccda4b','2026-10-29 16:20:20',NULL,'2026-10-22 08:20:20'),
(40,1,'6941086fa4df13ce68b201321b4687c9128b6e6dfa9b9aa68926924dff13a977','2026-10-29 16:20:40',NULL,'2026-10-22 08:20:41'),
(41,1,'c609f060a4102d71488b1d403fd7ab6c09e763a21319554f7a664283d700548d','2026-10-29 16:20:51',NULL,'2026-10-22 08:20:51'),
(42,1,'2fe41594cae2230d6139acb3750a9cbf67fb2fb76444a838ce3c1bb4c55bd87d','2026-10-29 16:23:14',NULL,'2026-10-22 08:23:14'),
(43,1,'b7d25bbbf682deeedce106e7d3f391167167bc7b6408aaf0569137a7ad9ca341','2026-10-29 16:25:13',NULL,'2026-10-22 08:25:13'),
(45,1,'cd97515fdf3b1595d93952dbfe9af5d6965c840e2b42c023dfc66bde2693a8a3','2026-10-29 16:30:33',NULL,'2026-10-22 08:30:33'),
(46,1,'ff537ff2591bb081082573b45624d2a3eac279adc329bb82e56bcd674ce1d7c7','2026-10-29 16:30:46',NULL,'2026-10-22 08:30:46'),
(47,1,'36b7bfea8302b8ec6ed476886a354b058c85bf8197f783137eff417830bdf9b6','2026-10-29 16:31:06',NULL,'2026-10-22 08:31:07'),
(51,1,'fe6c3510ca2a885224a3d3b6aea333ca3a4140c78f276a0290b2bd5610d18a99','2026-10-29 16:31:20',NULL,'2026-10-22 08:31:20'),
(52,1,'e17d2338b53bc46c2e8e8eb26e7d9550eca07fc90443719737fe65718d6229f5','2026-10-29 16:31:58',NULL,'2026-10-22 08:31:58'),
(54,1,'90bf903480bfdbe6aa21c6378436befc39c03ec07d5797d2845612abf1b85abf','2026-10-29 16:36:04',NULL,'2026-10-22 08:36:04'),
(55,1,'15150bbacf5cdfb038fb67e7ff869b022cee13479b0d161443c3815ae14fab68','2026-10-29 16:37:03',NULL,'2026-10-22 08:37:03'),
(56,1,'b8103b721a73259ae296b361bba417ffdb54eaad371a6c142cb67f5e73f3386d','2026-10-29 16:37:12',NULL,'2026-10-22 08:37:12'),
(57,1,'13fe04ba4d8085b003e814bbf7bb3fcc2eb4c32b8dc6aa19dd160d5056d04a47','2026-10-29 16:38:19',NULL,'2026-10-22 08:38:19'),
(59,1,'fbc11f356f2a200e86e61e59550b039df63071e0dec5d4cf9ad07ff7460943c3','2026-10-29 16:41:02',NULL,'2026-10-22 08:41:02'),
(60,1,'b12314900d54cc9d73fa35a0344c27dac6054e245288dbbbbdeaa5c12e674c73','2026-10-29 16:41:14',NULL,'2026-10-22 08:41:14'),
(61,1,'9893a28a7ca9797254b97ba77f4428684dadf391fdecd3ca84e8416c1a4b0716','2026-10-29 16:41:24',NULL,'2026-10-22 08:41:24'),
(62,1,'06efb76d8cfdbbfa44bb5002493d6219bccee3339bd5c52bacd7a66c4b11c46f','2026-10-29 16:43:52',NULL,'2026-10-22 08:43:52'),
(63,1,'bba38ecc8d054c6e3d5c764e9ec11d41f6813e764ba1a599442424991179b0cb','2026-10-29 16:45:46',NULL,'2026-10-22 08:45:46'),
(64,5,'81502f5b533ab9149fe67dbc9db69adba394275b85a4f24758b7698cc80c14b5','2026-10-29 16:46:22',NULL,'2026-10-22 08:46:22'),
(65,1,'738ce0712a80409dfcbae86320be3d5176181c795a3975aa513a2135a76f921c','2026-10-29 16:46:22',NULL,'2026-10-22 08:46:22'),
(67,1,'d77658334a0f43f3c61a506644435fc33b7a053a9c9d9d9c78c6dc6c7a72ddb6','2026-10-29 17:04:04',NULL,'2026-10-22 09:04:05'),
(68,1,'03db3e45957cf6ef37a873364ecf53427177269f7524c2e2764d4c12ae542faf','2026-10-31 20:58:27',NULL,'2026-10-24 12:58:27'),
(69,1,'3e59868365d314058cae86be555bc93d9d6f56fb9b9966b5343e14b54cf09462','2026-10-31 21:00:32',NULL,'2026-10-24 13:00:32'),
(70,1,'6a6dc000edc19be557473ef8194a98238754b889f6ff80c1552e1d14ffcc405d','2026-10-31 21:04:22',NULL,'2026-10-24 13:04:23'),
(71,1,'0279da7dd5ffe246a227a770064f23caa864250aeb0fb1bc8dfe6c17faeb9a8e','2026-10-31 21:05:36',NULL,'2026-10-24 13:05:36'),
(72,1,'005f8b2cb771759bd48765d43e39dcb92e5fea485c2f940adb6a1f3098680968','2026-10-31 21:06:49',NULL,'2026-10-24 13:06:50'),
(73,1,'951cac6f9fa5933c6995dadbe72d0f9aac69f6bedd9f22244b122341fefd9a52','2026-10-31 21:07:50',NULL,'2026-10-24 13:07:50'),
(76,1,'95220e4669eee3bd5e36eb00283fdb8f195fce42102f2c444e3c259406bb69ec','2026-11-01 07:07:41',NULL,'2026-10-24 23:07:41');

DROP TABLE IF EXISTS `reports`;
CREATE TABLE "reports" (
  "report_id" int unsigned NOT NULL AUTO_INCREMENT,
  "reporter_id" int DEFAULT NULL,
  "reported_user_id" int DEFAULT NULL,
  "reason" varchar(255) NOT NULL,
  "status" enum('open','resolved') NOT NULL DEFAULT 'open',
  "created_at" datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "resolved_at" datetime DEFAULT NULL,
  PRIMARY KEY ("report_id"),
  KEY "fk_report_reporter" ("reporter_id"),
  KEY "fk_report_user" ("reported_user_id"),
  CONSTRAINT "fk_report_reporter" FOREIGN KEY ("reporter_id") REFERENCES "users" ("id") ON DELETE SET NULL,
  CONSTRAINT "fk_report_user" FOREIGN KEY ("reported_user_id") REFERENCES "users" ("id") ON DELETE CASCADE
);


DROP TABLE IF EXISTS `saved_items`;
CREATE TABLE "saved_items" (
  "user_id" int NOT NULL,
  "listing_id" int unsigned NOT NULL,
  "created_at" datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY ("user_id","listing_id"),
  KEY "fk_saved_listing" ("listing_id"),
  CONSTRAINT "fk_saved_listing" FOREIGN KEY ("listing_id") REFERENCES "marketplace_listings" ("listing_id") ON DELETE CASCADE,
  CONSTRAINT "fk_saved_user" FOREIGN KEY ("user_id") REFERENCES "users" ("id") ON DELETE CASCADE
);


DROP TABLE IF EXISTS `shipments`;
CREATE TABLE "shipments" (
  "shipment_id" int NOT NULL AUTO_INCREMENT,
  "batch_id" int NOT NULL,
  "transporter_id" int NOT NULL,
  "vehicle_number" varchar(50) DEFAULT NULL,
  "origin" varchar(255) NOT NULL,
  "destination" varchar(255) NOT NULL,
  "dispatch_time" datetime DEFAULT NULL,
  "delivery_time" datetime DEFAULT NULL,
  "shipment_status" enum('pending','in_transit','delivered','cancelled') NOT NULL DEFAULT 'pending',
  "remarks" text,
  "created_at" datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY ("shipment_id"),
  KEY "fk_ship_batch" ("batch_id"),
  KEY "fk_ship_transporter" ("transporter_id"),
  CONSTRAINT "fk_ship_batch" FOREIGN KEY ("batch_id") REFERENCES "product_batches" ("batch_id"),
  CONSTRAINT "fk_ship_transporter" FOREIGN KEY ("transporter_id") REFERENCES "users" ("id")
);


DROP TABLE IF EXISTS `trace_codes`;
CREATE TABLE "trace_codes" (
  "trace_id" int NOT NULL AUTO_INCREMENT,
  "trace_code" varchar(40) NOT NULL,
  "order_id" int unsigned NOT NULL,
  "order_item_id" int unsigned NOT NULL,
  "listing_id" int unsigned DEFAULT NULL,
  "buyer_id" int NOT NULL,
  "seller_id" int NOT NULL,
  "product_name" varchar(150) NOT NULL,
  "category" varchar(50) DEFAULT NULL,
  "quantity" decimal(12,2) NOT NULL,
  "unit" varchar(30) NOT NULL,
  "unit_price" decimal(12,2) NOT NULL,
  "qr_url" varchar(500) DEFAULT NULL,
  "created_at" datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY ("trace_id"),
  UNIQUE KEY "trace_code" ("trace_code"),
  UNIQUE KEY "order_item_id" ("order_item_id"),
  KEY "fk_trace_order" ("order_id"),
  KEY "fk_trace_buyer" ("buyer_id"),
  KEY "fk_trace_seller" ("seller_id"),
  CONSTRAINT "fk_trace_buyer" FOREIGN KEY ("buyer_id") REFERENCES "users" ("id"),
  CONSTRAINT "fk_trace_item" FOREIGN KEY ("order_item_id") REFERENCES "order_items" ("item_id") ON DELETE CASCADE,
  CONSTRAINT "fk_trace_order" FOREIGN KEY ("order_id") REFERENCES "orders" ("order_id") ON DELETE CASCADE,
  CONSTRAINT "fk_trace_seller" FOREIGN KEY ("seller_id") REFERENCES "users" ("id")
);


DROP TABLE IF EXISTS `traceability_logs`;
CREATE TABLE "traceability_logs" (
  "log_id" int NOT NULL AUTO_INCREMENT,
  "batch_id" int NOT NULL,
  "updated_by" int NOT NULL,
  "status" enum('harvested','collected','in_transit','received','available_at_market','sold','rejected') NOT NULL,
  "location_name" varchar(255) DEFAULT NULL,
  "latitude" decimal(10,7) DEFAULT NULL,
  "longitude" decimal(10,7) DEFAULT NULL,
  "remarks" text,
  "created_at" datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY ("log_id"),
  KEY "fk_trace_batch" ("batch_id"),
  KEY "fk_trace_user" ("updated_by"),
  CONSTRAINT "fk_trace_batch" FOREIGN KEY ("batch_id") REFERENCES "product_batches" ("batch_id"),
  CONSTRAINT "fk_trace_user" FOREIGN KEY ("updated_by") REFERENCES "users" ("id")
);


DROP TABLE IF EXISTS `user_follows`;
CREATE TABLE "user_follows" (
  "follower_id" int NOT NULL,
  "followee_id" int NOT NULL,
  "created_at" datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY ("follower_id","followee_id"),
  KEY "fk_follow_to" ("followee_id"),
  CONSTRAINT "fk_follow_from" FOREIGN KEY ("follower_id") REFERENCES "users" ("id") ON DELETE CASCADE,
  CONSTRAINT "fk_follow_to" FOREIGN KEY ("followee_id") REFERENCES "users" ("id") ON DELETE CASCADE
);

INSERT INTO `user_follows` (`follower_id`,`followee_id`,`created_at`) VALUES
(1,5,'2026-10-22 08:26:51');

DROP TABLE IF EXISTS `users`;
CREATE TABLE "users" (
  "id" int NOT NULL AUTO_INCREMENT,
  "username" varchar(150) NOT NULL,
  "first_name" varchar(100) DEFAULT NULL,
  "middle_name" varchar(100) DEFAULT NULL,
  "last_name" varchar(100) DEFAULT NULL,
  "address" text,
  "email" varchar(150) NOT NULL,
  "password" varchar(255) NOT NULL,
  "role" enum('admin','farmer','collector','transporter','seller') NOT NULL,
  "is_active" tinyint(1) NOT NULL DEFAULT '1',
  "created_at" datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  "age" tinyint unsigned DEFAULT NULL,
  "gender" varchar(20) DEFAULT NULL,
  "contact_number" varchar(30) DEFAULT NULL,
  "profile_pic" varchar(255) DEFAULT NULL,
  "two_factor_code_hash" varchar(64) DEFAULT NULL,
  "two_factor_expires_at" datetime DEFAULT NULL,
  "two_factor_attempts" tinyint unsigned NOT NULL DEFAULT '0',
  "password_reset_hash" varchar(64) DEFAULT NULL,
  "password_reset_expires_at" datetime DEFAULT NULL,
  "latitude" decimal(9,6) DEFAULT NULL,
  "longitude" decimal(9,6) DEFAULT NULL,
  "location_label" varchar(255) DEFAULT NULL,
  PRIMARY KEY ("id"),
  UNIQUE KEY "email" ("email")
);

INSERT INTO `users` (`id`,`username`,`first_name`,`middle_name`,`last_name`,`address`,`email`,`password`,`role`,`is_active`,`created_at`,`updated_at`,`age`,`gender`,`contact_number`,`profile_pic`,`two_factor_code_hash`,`two_factor_expires_at`,`two_factor_attempts`,`password_reset_hash`,`password_reset_expires_at`,`latitude`,`longitude`,`location_label`) VALUES
(1,'Miko Joshua PH',NULL,NULL,NULL,NULL,'mikojoshuaph@gmail.com','$2y$10$lY2Ihb.8LTkG1XH.Wvu0mu.4bziOpniJFvs7EsBeJXTJYfDoVbRBq','admin',1,'2026-10-17 23:51:26','2026-10-25 07:09:58',NULL,NULL,NULL,'/uploads/cloud/community/202610/53edef826e78d13d751d3a44aa49256a.jpg',NULL,NULL,0,NULL,NULL,'13.371806','121.144447','Tawagan Elementary School, Highway to Tawagan, Calapan, 5200 MR, Philippines'),
(2,'Miko',NULL,NULL,NULL,NULL,'mikojoshua99@gmail.com','$2y$10$1wfWqSXxIVrxd8flMzOJlO9Q.P0rqfrZt92RHOPhG0/EN7.BV6Pt.','admin',1,'2026-10-18 00:45:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL),
(3,'Danny','Roldan',NULL,NULL,NULL,'da@gmail.com','$2y$10$24dGMGCnt7BpNnymbD3f9uY8wC.EVA9a20aM6ZiMQdgaIZsDskWaC','admin',1,'2026-10-18 00:47:02','2026-10-18 00:59:01',NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL),
(4,'Madie',NULL,NULL,NULL,NULL,'madie@gmail.com','$2y$10$d7lnAaMdLytTDVs11ZIiyOjBGf9W8aup01Qa6jf6I6p0mCmP4kR6O','admin',1,'2026-10-18 00:52:57',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL),
(5,'JOSEPH DELA CRUZ','JOSEPH','DIMALALUAN','DELA CRUZ','HOLY SPIRIT STREET','mikojoshua@gmail.com','$2y$10$4AUzQmYKnQQ1NXe0CeDQeebQOGSud2a5XMtAEgJUDWYeneefTxDMG','farmer',1,'2026-10-20 17:21:44',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL);

DROP TABLE IF EXISTS `weather_records`;
CREATE TABLE "weather_records" (
  "weather_id" int NOT NULL AUTO_INCREMENT,
  "farm_id" int NOT NULL,
  "harvest_id" int DEFAULT NULL,
  "temperature" decimal(5,2) DEFAULT NULL,
  "humidity" decimal(5,2) DEFAULT NULL,
  "weather_condition" varchar(100) DEFAULT NULL,
  "rainfall_mm" decimal(8,2) DEFAULT NULL,
  "recorded_at" datetime NOT NULL,
  PRIMARY KEY ("weather_id"),
  KEY "fk_weather_farm" ("farm_id"),
  KEY "fk_weather_harvest" ("harvest_id"),
  CONSTRAINT "fk_weather_farm" FOREIGN KEY ("farm_id") REFERENCES "farms" ("farm_id"),
  CONSTRAINT "fk_weather_harvest" FOREIGN KEY ("harvest_id") REFERENCES "harvest_records" ("harvest_id")
);


SET FOREIGN_KEY_CHECKS=1;
